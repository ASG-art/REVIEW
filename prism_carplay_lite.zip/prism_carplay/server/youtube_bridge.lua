-- Fetch metadata from the server rather than from the CEF/NUI browser.
-- No external licensing API or secret is needed. Only YouTube hosts are accepted.
local lastRequest = {}
local function videoId(url)
    if type(url) ~= 'string' or #url > 2048 then return nil end
    local host, path = url:match('^https://([^/%?#]+)([^#]*)')
    if not host then return nil end
    host = host:lower()
    local id
    if host == 'youtu.be' or host == 'www.youtu.be' then
        id = path:match('^/([%w_-]+)')
    elseif host == 'youtube.com' or host == 'www.youtube.com' or host == 'm.youtube.com' or host == 'music.youtube.com' then
        id = path:match('[?&]v=([%w_-]+)') or path:match('^/shorts/([%w_-]+)') or path:match('^/embed/([%w_-]+)')
    end
    if id and #id == 11 then return id end
    return nil
end

RegisterNetEvent('prism-carplay:metadata:request', function(requestId, url)
    local player = source
    if type(requestId) ~= 'number' or requestId < 1 or requestId > 1000000000 then return end
    local now = GetGameTimer()
    if lastRequest[player] and now - lastRequest[player] < 500 then return end
    lastRequest[player] = now
    local id = videoId(url)
    if not id then
        TriggerClientEvent('prism-carplay:metadata:response', player, requestId, {status = 'error', error = 'Unsupported YouTube URL'})
        return
    end
    local metadataUrl = 'https://www.youtube.com/oembed?url=https%3A%2F%2Fwww.youtube.com%2Fwatch%3Fv%3D' .. id .. '&format=json'
    PerformHttpRequest(metadataUrl, function(status, body)
        local result = {status = 'error', error = 'Metadata request failed'}
        if status == 200 and type(body) == 'string' then
            local ok, data = pcall(json.decode, body)
            if ok and type(data) == 'table' and type(data.title) == 'string' then
                result = {status = 'success', title = data.title:sub(1, 200), duration = 0}
            end
        end
        if GetPlayerName(player) then
            TriggerClientEvent('prism-carplay:metadata:response', player, requestId, result)
        end
    end, 'GET', '', {['Accept'] = 'application/json'})
end)

AddEventHandler('playerDropped', function() lastRequest[source] = nil end)
