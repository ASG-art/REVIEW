-- Server-authoritative audio transport. All clients follow this clock, not each other.
local sources, speakers, callbacks, requestTimes = {}, {}, {}, {}
local serial = 0
local function finite(n) return type(n) == 'number' and n == n and math.abs(n) < math.huge end
local function clock() return GetGameTimer() / 1000 end
local function position(s)
    local value = s.position + (s.playing and math.max(0, clock() - s.anchor) or 0)
    if s.duration and s.duration > 0 then
        if s.options.loop then return value % s.duration end
        return math.min(value, s.duration)
    end
    return value
end
function AssignOwner()
    local owner, ping
    for _, player in ipairs(GetPlayers()) do
        local latency = GetPlayerPing(player)
        if tonumber(player) ~= tonumber(source) and (not ping or latency < ping) then owner, ping = tonumber(player), latency end
    end
    return owner
end
function createSourceID() serial = serial + 1; return 'audio_' .. serial end
local function call(id, event, data)
    local cb = callbacks[id] and callbacks[id][event]
    if cb then cb(data) end
end
local function state(id, s)
    return {id=id, generation=s.generation, revision=s.revision, position=position(s), playing=s.playing, duration=s.duration, loop=s.options.loop == true}
end
local function broadcast(id, target)
    local s = sources[id]
    if s then TriggerClientEvent('prism-carplay:audio:clock', target or -1, state(id, s)) end
end
function GetAudioSourceState(id)
    local s = sources[tostring(id)]
    if not s then return nil end
    return state(tostring(id), s)
end
function AddAudioSource(id, url, options, events)
    id = tostring(id or createSourceID())
    if type(url) ~= 'string' then return false end
    if sources[id] then RemoveAudioSource(id) end
    serial = serial + 1
    options = options or {}
    options.generation = serial
    local owner
    for _, p in ipairs(GetPlayers()) do owner = tonumber(p); break end
    local flags = {}
    callbacks[id] = events or {}
    for event in pairs(callbacks[id]) do flags[event] = true end
    -- Always receive readiness/end/error, even when no external callback was supplied.
    flags.onAudioReady, flags.onAudioEnded, flags.onAudioError, flags.onPlaybackStarted = true, true, true, true
    sources[id] = {url=url, options=options, flags=flags, owner=owner, generation=serial,
        revision=0, position=0, anchor=clock(), createdAt=clock(), playing=false, ready=false}
    TriggerClientEvent('ts-sounds:client:AddSource', -1, id, url, options, flags, true, owner)
    return id
end
function RemoveAudioSource(id)
    id = tostring(id)
    sources[id], callbacks[id] = nil, nil -- invalidate before clients acknowledge destruction
    for key, speaker in pairs(speakers) do if speaker.source == id then speakers[key] = nil end end
    TriggerClientEvent('ts-sounds:client:RemoveSource', -1, id)
end
function AddSpeaker(id, location, options, audioId)
    audioId = tostring(audioId)
    if not sources[audioId] then return false end
    speakers[id] = {position=location, options=options, source=audioId}
    TriggerClientEvent('ts-sounds:client:AddSpeaker', -1, id, location, options, audioId)
end
function SetSpeakerVolume(id, volume)
    if not finite(volume) then return end
    volume = math.max(0, math.min(1, volume))
    if speakers[id] then speakers[id].options.volumeMultiplier = volume end
    TriggerClientEvent('ts-sounds:client:SetSpeakerVolume', -1, id, volume)
end
function SetLoop(id, loop)
    local s = sources[tostring(id)]
    if not s then return end
    s.position, s.anchor = position(s), clock()
    s.options.loop = loop == true
    s.revision = s.revision + 1
    broadcast(tostring(id))
    TriggerClientEvent('ts-sounds:client:SetAudioLoop', -1, id, s.options.loop)
end
function PlayAudioSource(id)
    id = tostring(id); local s = sources[id]; if not s then return end
    s.position, s.anchor, s.playing, s.started = 0, clock(), true, true
    s.revision = s.revision + 1
    broadcast(id); call(id, 'onPlaybackStarted')
end
function PauseAudioSource(id)
    id = tostring(id); local s = sources[id]; if not s or not s.playing then return end
    s.position, s.anchor, s.playing = position(s), clock(), false
    s.revision = s.revision + 1
    broadcast(id); call(id, 'onPlaybackPaused')
end
function ResumeAudioSource(id)
    id = tostring(id); local s = sources[id]; if not s or s.playing then return end
    s.anchor, s.playing = clock(), true
    s.revision = s.revision + 1
    broadcast(id); call(id, 'onPlaybackResumed')
end
function SeekAudioSource(id, seconds)
    id = tostring(id); local s = sources[id]
    if not s or not finite(seconds) then return end
    s.position = math.max(0, seconds)
    if s.duration and s.duration > 0 then s.position = math.min(s.position, s.duration) end
    s.anchor = clock(); s.revision = s.revision + 1
    broadcast(id)
end
local function finish(id)
    local cb = callbacks[id] and callbacks[id].onAudioEnded
    RemoveAudioSource(id)
    if cb then cb() end
end
RegisterNetEvent('ts-sounds:server:AudioCallback', function(id, event, data)
    id = tostring(id); local s = sources[id]
    if not s or tonumber(source) ~= s.owner or type(data) ~= 'table' or data.generation ~= s.generation then return end
    if event == 'onAudioReady' then
        if finite(data.duration) and data.duration > 0 then s.duration = data.duration end
        if not s.ready then s.ready = true; call(id, event, data) end
    elseif event == 'onPlaybackStarted' then
        if finite(data.duration) and data.duration > 0 and data.duration ~= s.duration then
            s.duration = data.duration
            TriggerEvent('prism-carplay:audio:duration', id, s.duration)
        end
    elseif event == 'onAudioEnded' then
        -- Ignore premature local ends caused by buffering, seek, or source replacement.
        if s.playing and not s.options.loop and s.duration and position(s) >= s.duration - 1 then finish(id) end
    elseif event == 'onAudioError' then
        call(id, event, data)
        if sources[id] == s then RemoveAudioSource(id) end
    end
end)
-- Legacy removal notifications are intentionally ignored: only the server owns lifetime.
RegisterNetEvent('ts-sounds:server:RemoveAudioSource', function() end)
RegisterNetEvent('prism-carplay:audio:requestSnapshot', function()
    local player = source; local now = clock()
    if requestTimes[player] and now - requestTimes[player] < 2 then return end
    requestTimes[player] = now
    local snapshot = {sources={}, speakers={}}
    for id, s in pairs(sources) do
        local item = state(id, s)
        item.url, item.options, item.flags, item.owner = s.url, s.options, s.flags, s.owner
        snapshot.sources[#snapshot.sources+1] = item
    end
    for id, s in pairs(speakers) do
        snapshot.speakers[#snapshot.speakers+1] = {id=id, position=s.position, options=s.options, source=s.source}
    end
    TriggerClientEvent('prism-carplay:audio:snapshot', player, snapshot)
end)
AddEventHandler('playerDropped', function()
    local departed = tonumber(source); requestTimes[source] = nil
    for id, s in pairs(sources) do
        if s.owner == departed then
            s.owner = AssignOwner()
            TriggerClientEvent('ts-sounds:client:ChangeOwner', -1, id, s.owner)
        end
    end
end)
CreateThread(function()
    while true do
        Wait(2000)
        for id, s in pairs(sources) do
            if not s.ready and clock() - s.createdAt >= 25 then
                call(id, 'onAudioError', {message='Audio load timeout'})
                if sources[id] == s then RemoveAudioSource(id) end
            elseif s.playing and not s.options.loop and s.duration and position(s) >= s.duration then finish(id)
            else broadcast(id) end
        end
    end
end)
for name, fn in pairs({AddAudioSource=AddAudioSource, RemoveAudioSource=RemoveAudioSource,
    AddSpeaker=AddSpeaker, PlayAudioSource=PlayAudioSource, PauseAudioSource=PauseAudioSource,
    ResumeAudioSource=ResumeAudioSource, SeekAudioSource=SeekAudioSource,
    SetSpeakerVolume=SetSpeakerVolume, SetLoop=SetLoop, GetAudioSourceState=GetAudioSourceState}) do exports(name, fn) end
