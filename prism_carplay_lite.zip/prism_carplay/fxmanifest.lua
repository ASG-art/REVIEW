

fx_version 'cerulean'
game 'gta5'

author 'Prism'
description 'Prism CarPlay'
version '1.0.2'

lua54 'yes'

ui_page 'web/dist/index.html'

shared_scripts {
    'config.lua',
    'locales/locales.lua',
    'locales/*.lua'
}

client_scripts {
    'client/sound.lua',
    'client/youtube_bridge.lua',
    'client/disable_radio_wheel.lua',
    'client/main.lua'
}

server_scripts {
    'server/sound.lua',
    'server/youtube_bridge.lua',
    'server/server.js',
    'server/main.lua',
    'server/items.lua'
}

files {
    'web/dist/index.html',
    'web/dist/**/*',
    'recordings/dashcam/*.webm'
}

escrow_ignore{
    'config.lua',
    'locales/locales.lua',
    'locales/*.lua'
}

dependency '/assetpacks'

