-- Prism CarPlay: server-side YouTube metadata bridge (avoids NUI CORS failures).
local pending = {}
local requestId = 0

function PrismFetchYouTubeData(url, callback)
    if type(callback) ~= 'function' then return end
    if type(url) ~= 'string' or #url > 2048 or not url:match('^https://') then
        callback({status = 'error', error = 'Invalid YouTube URL'})
        return
    end
    requestId = requestId + 1
    local id = requestId
    pending[id] = callback
    TriggerServerEvent('prism-carplay:metadata:request', id, url)
    SetTimeout(9000, function()
        if pending[id] then
            local cb = pending[id]
            pending[id] = nil
            cb({status = 'error', error = 'YouTube metadata timeout'})
        end
    end)
end

RegisterNetEvent('prism-carplay:metadata:response', function(id, result)
    local cb = pending[id]
    if not cb then return end
    pending[id] = nil
    cb(type(result) == 'table' and result or {status = 'error', error = 'Invalid response'})
end)
