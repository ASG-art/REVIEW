-- B9 CarPlay: hide the GTA V radio selection wheel while inside vehicles.
-- Wait(0) is only needed while the player is in a vehicle; otherwise sleep.
CreateThread(function()
    while true do
        local ped = PlayerPedId()
        if IsPedInAnyVehicle(ped, false) then
            -- INPUT_VEH_RADIO_WHEEL (Q / controller radio wheel)
            DisableControlAction(0, 85, true)
            Wait(0)
        else
            Wait(1000)
        end
    end
end)
